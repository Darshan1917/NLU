from flask import Flask
from flask import render_template,jsonify,request
import requests
from engine import *
import random


app = Flask(__name__)
app.secret_key = '12345'

@app.route('/')
def hello_world():
    return render_template('home.html')

get_random_response = lambda intent:random.choice(intent_response_dict[intent])

@app.route('/chat',methods=["POST"])
def chat():
    try:
        user_message = request.form["text"]
        response = requests.get("http://127.0.0.1:5000/parse",params={"q":user_message})
        response = response.json()
        print(response)
        entities = response.get("entities")#,"fleetflex","technical_issue"]#response.get("entities")
        print (entities)
        topresponse = response["topScoringIntent"]
        intent = topresponse.get("intent")
        print("Intent->{}, Entities->{}, TopResponse->{}".format(intent,entities,topresponse))
        if intent == "access_Issue": #You need to have as many if conditions checking for different Intents in Question & Answers
            response_text = access_Issue(entities)# Similarly we need call separate method defined in engine.py for each Intent
        elif intent == "fleetflex_access":
            response_text = fleetflex_access(entities)
        elif intent == "technical":
            response_text = technical(entities)
        elif intent == "documents":
            response_text = documents(entities)
        else:
            response_text = get_random_response(intent)
        return jsonify({"status":"success","response":response_text})
    except Exception as e:
        print(e)
        return jsonify({"status":"success","response":"Sorry I am not trained to do that yet..."}) #Default response, when restapi fails


app.config["DEBUG"] = True
if __name__ == "__main__":
    app.run(port=8080)  # Change the UI port if needed
