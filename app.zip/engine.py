
##dict of response for each type of intent
#Response for common questions
intent_response_dict = {
    "intro": ["This is a GE Measurement FAQ bot. One stop-shop to all your GST related queries"],
    "greet":["Hey","Hello","Hi"],
    "goodbye":["Bye","It was nice talking to you","See you","ttyl"],
    "affirm":["Cool","I know you would like it"]
}
default_response_dict = {
    "faq_link":'You can check all the answers here https://www.gemeasurement.com/frequently-asked-questions'
}

#Dictionary is the form
#"entity" : "answer for the question to which the entity belongs to"
ge_support_object_dict = {
    "access icam":"Here is a method to access icam",
    "how to":"Here is a method to access icam"
}

ge_query_object_dict = {
    "how to access":"Here is a link and description for fleetflex access\n"
                    "Here is a method to access fleetflex :\n Steps 1 click on the link https://idm.infra.ge.com/idm/user/geidm/home.xhtml\n"
                    "step 2 : search for predix application",
    "application document":"links for documentation \n 1. iCAM - https://devcloud.swcoe.ge.com/devspace/display/AHIZL/ICAM+Home\n 2.Fleetflex - https://devcloud.swcoe.ge.com/devspace/display/ZJFXQ/Home ",
    "application documents":"links for documentation \n 1. iCAM - https://devcloud.swcoe.ge.com/devspace/display/AHIZL/ICAM+Home\n 2.Fleetflex - https://devcloud.swcoe.ge.com/devspace/display/ZJFXQ/Home",
    "documents":"links for documentation \n 1. iCAM - https://devcloud.swcoe.ge.com/devspace/display/AHIZL/ICAM+Home\n 2.Fleetflex - https://devcloud.swcoe.ge.com/devspace/display/ZJFXQ/Home",
    "docs":"links for documentation \n 1. iCAM - https://devcloud.swcoe.ge.com/devspace/display/AHIZL/ICAM+Home\n 2.Fleetflex - https://devcloud.swcoe.ge.com/devspace/display/ZJFXQ/Home",
    "access icam":"Here is a method to access icam :\n Steps 1 : click on oneidm link https://idm.infra.ge.com/idm/user/geidm/home.xhtml \n"
                  "step 2 : search for icam application",
    "how to":"Here is a method to access icam :\n Steps 1 : click on oneidm link https://idm.infra.ge.com/idm/user/geidm/home.xhtml \n"
                  "step 2 : search for icam application ",
    "icam access":"Here is a method to access icam:\n Steps 1 : click on oneidm link https://idm.infra.ge.com/idm/user/geidm/home.xhtml \n"
                  "step 2 : search for icam application ",
    "fleetflex application":"Here is a link and description for fleetflex access\n "
                    "Here is a method to access fleetflex :\n Steps 1 click on the link https://idm.infra.ge.com/idm/user/geidm/home.xhtml \n"
                    "step 2 : search for predix application",
    "access fleetflex":"Here is a link and description for fleetflex access\n"
                    "Here is a method to access fleetflex :\n Steps 1 click on the link https://idm.infra.ge.com/idm/user/geidm/home.xhtml \n"
                    "step 2 : search for predix application",
    "fleetflex access":"Here is a link and description for fleetflex access\n"
                    "Here is a method to access fleetflex :\n Steps 1 click on the link https://idm.infra.ge.com/idm/user/geidm/home.xhtml \n"
                    "step 2 : search for predix application",
    "technical help":"Email id of the support team for technical assistance is @AVIATION CSA L2 Support Team dlaviation.csaitsupport@ge.com ",
    "technical issue":"Email id of the support team for technical assistance is @AVIATION CSA L2 Support Team dlaviation.csaitsupport@ge.com",
    "technical support": "Email id of the support team for technical assistance is @AVIATION CSA L2 Support Team dlaviation.csaitsupport@ge.com"
}


def access_Issue(entities):
    print (entities)
    if entities == None:
        return "Could not find out specific information about this ..." +  default_response_dict["faq_link"] #Default response, when Intent is identified but not Entity
    if len(entities):
        print ('Key word is->', entities[0]['entity'])
        return ge_query_object_dict[entities[0]['entity']]
    return "Sorry.." + default_response_dict["faq_link"] #Default response when there are no matching entity in the dictionary

def fleetflex_access(entities):
    print(entities)
    if entities == None:
        return "Could not find out specific information about this ..." +  default_response_dict["faq_link"] #Default response, when Intent is identified but not Entity
    if len(entities):
        print ('Key word is->', entities[0]['entity'])
        return ge_query_object_dict[entities[0]['entity']]
    return "Sorry.." + default_response_dict["faq_link"] #Default response when there are no matching entity in the dictionary

def documents(entities):
    print (entities)
    if entities == None:
        return "Could not find out specific information about this ..." +  default_response_dict["faq_link"] #Default response, when Intent is identified but not Entity
    if len(entities):
        print ('Key word is->', entities[0]['entity'])
        return ge_query_object_dict[entities[0]['entity']]
    return "Sorry.." + default_response_dict["faq_link"] #Default response when there are no matching entity in the dictionary

def technical(entities):
    print (entities)
    if entities == None:
        return "Could not find out specific information about this ..." +  default_response_dict["faq_link"] #Default response, when Intent is identified but not Entity
    if len(entities):
        print ('Key word is->', entities[0]['entity'])
        return ge_query_object_dict[entities[0]['entity']]
    return "Sorry.." + default_response_dict["faq_link"] #Default response when there are no matching entity in the dictionary

