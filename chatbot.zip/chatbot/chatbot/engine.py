
##dict of response for each type of intent
#Response for common questions
intent_response_dict = {
    "intro": ["This is a GE Measurement FAQ bot. One stop-shop to all your GST related queries"],
    "greet":["Hey","Hello","Hi"],
    "goodbye":["Bye","It was nice talking to you","See you","ttyl"],
    "affirm":["Cool","I know you would like it"]
}
default_response_dict = {
    "faq_link":'You can check all the answers here https://www.gemeasurement.com/frequently-asked-questions'
}

#Dictionary is the form
#"entity" : "answer for the question to which the entity belongs to"
ge_support_object_dict = {
    "rotor":"Overhung rotors have characteristics such as Disk Skew and Gyroscopic Effects that can make them difficult or impossible to balance with standard single or dual plane balancing techniques",
    "pt878":"Please watch the below video with instructions on for setting up PT878: https://www.youtube.com/playlist?list=PLf5aGxd5yPUEKRLNhPQsWAVJh_ZrXR69i",
    "refrigerator":"This answer is fabricated, so dont believe this https://www.youtube.com/playlist?list=PLf5aGxd5yPUEKRLNhPQsWAVJh_ZrXR69i",
    "vbseries":"SCOUT / vbSeries instruments have very stable hardware and firmware. However, we recommend yearly performance checks for the instruments and a full calibration during the final year of warranty",
    "accelerometers":"SCOUT / vbSeries instruments have very stable hardware and firmware. However, we recommend yearly performance checks for the instruments and a full calibration during the final year of warranty",
    "scout":"SCOUT / vbSeries instruments have very stable hardware and firmware. However, we recommend yearly performance checks for the instruments and a full calibration during the final year of warranty",
    "dpi 610":"To over-ride an unknown PIN use the PIN 6100 followed immediately by pressing the SETUP key (not the ENTER key)",
    "dpi 610/615":"To over-ride an unknown PIN use the PIN 6100 followed immediately by pressing the SETUP key (not the ENTER key)",
    "dpi 615":"To over-ride an unknown PIN use the PIN 6100 followed immediately by pressing the SETUP key (not the ENTER key)",
    "pin 4321":"To over-ride an unknown PIN use the PIN 6100 followed immediately by pressing the SETUP key (not the ENTER key)",
    "pin 000":"First check that the CAL enable link (LK1) located on the rear of the PCB is fitted in the checked position. If the link is not in the checked position then move the link to the checked position and re-enter the pin 000"
}

ge_query_object_dict = {
    "tasks":"Yes. We recommend you work through the list of pre-balance procedures",
    "10816":"This standard establishes the general conditions and procedures for the measurement and evaluation of vibration, using measurements made on the non-rotating parts of machines",
    "technical":"In the main website menu click Contacts Us >> select I need Support or Service for my GE product >> click Service Directory",
    "support":"In the main website menu click Contacts Us >> select I need Support or Service for my GE product >> click Service Directory",
    "contact":"In the main website menu click Contacts Us >> select I need Support or Service for my GE product >> click Service Directory",
    "pt878":"This condition is a result of the battery power being too low such that it corrupts the bootup file"
}


def technical_support(entities):
    if entities == None:
        return "Could not find out specific information about this ..." +  default_response_dict["faq_link"] #Default response, when Intent is identified but not Entity
    if len(entities):
        return ge_support_object_dict[entities[0]['entity']]
    return "Sorry.." + default_response_dict["faq_link"] #Default response when there are no matching entity in the dictionary

def technical_query(entities):
    if entities == None:
        return "Could not find out specific information about this ..." +  default_response_dict["faq_link"] #Default response, when Intent is identified but not Entity
    if len(entities):
        return ge_query_object_dict[entities[0]['entity']]
    return "Sorry.." + default_response_dict["faq_link"] #Default response when there are no matching entity in the dictionary

